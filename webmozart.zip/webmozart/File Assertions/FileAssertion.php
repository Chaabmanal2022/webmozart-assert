<?php

require_once '../vendor/autoload.php';

use Webmozart\Assert\Assert;


//Check that a value is an existing path
Assert::fileExists("C:\xampp\htdocs\webmozart",'path inexistant');

//Check that a value is an existing file
Assert::file("webmozart",'fichier inexistant');

//Check that a value is an existing directory
Assert::directory("C:\xampp",'directory inexistant');

//Check that a value is a readable path
Assert::readable("C:\xampp",'NOT A READABLE PATH');


//Check that a value is a writable path
Assert::writable("C:\xampp",'NOT A WRITABLE PATH');


?>

