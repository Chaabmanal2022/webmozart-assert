<?php

require_once '../vendor/autoload.php';

use Webmozart\Assert\Assert;
use RuntimeException;


//Check that a string contains a substring
array('contains', array('abcd', 'bc'), true);

//Check that a string does not contain a substring
array('notContains', array('abcd', 'ab'), false);

//Check that a string has a prefix
array('startsWith', array('abcd', 'ab'), true);

//Check that a string does not have a prefix
array('notStartsWith', array('abcd', 'bc'), true);

//Check that a string has a suffix
array('endsWith', array('abcd', 'cd'), true);

//Check that a string contains lowercase characters only
array('lower', array('abcd'), true);

//Check that a string contains uppercase characters only
array('upper', array('ABcD'), false);

//Check that a string has a certain number of characters
array('length', array('abcd', 4), true);

//Check that a string is a valid e-mail address
array('email', array('manalchaab2002@gmail.com'), false);

//Check that a string is a valid IPv6
array('ipv6', array('::ffff:192.0.2.1'), true);

//Check that a string is a valid IPv4
array('ipv4', array('192.168.0.1'), true);


?>