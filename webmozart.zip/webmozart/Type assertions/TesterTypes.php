<?php

require_once '../vendor/autoload.php';

use Webmozart\Assert\Assert;

//Check that a value is a string
Assert::string("hello", 'la valeur n est pas une chaine');

//Check that a value is a non-empty string
Assert::stringNotEmpty("",'STRING EMPTY');

//Check that a value is an integer
Assert::integer(21, 'LA VALEUR N EST PAS UN ENTIER');

//Check that a value casts to an integer
Assert::integerish("bonsoir",'PAS DE CASTING');

//Check that a value is a positive (non-zero) integer
Assert::positiveInteger(-11,'VALEUR NEGATIVE OU NULL!');

//Check that a value is a float
Assert::float(21.12, 'LA VALEUR N EST PAS UN FLOAT');

//Check that a value is numeric
Assert::numeric("HELLO WORLD!",'VALEUR N EST PAS NUMERIQUE');

//Check that a value is a boolean
Assert::boolean(TRUE,'VALEUR N EST PAS BOOLEAN');

//Check that a value is an array
$VAR=array();
Assert::isArray($VAR,'PAS DE TABLEAU');

//fonction a le meme role que isArray
Assert::isArrayAccessible($VAR,'PAS DE TABLEAU');
array('uniqueValues', array(array(123, '123')), false);

//Check that a value is of the class or has one of its parents
array('isAOf', array(array(), 'Iterator'), false);

//Check that the given array contains unique values
array('uniqueValues', array(array(123, '123')), false);

?>






