<?php

require_once '../vendor/autoload.php';

use Webmozart\Assert\Assert;


//Check that a value is true
array('true', array(true), true);

//Check that a value is false
array('false', array(false), true);

//Check that a value is not false
array('notFalse', array(false), false);

//Check that a value is null
array('null', array(0), false);

//Check that a value is not null
array('notNull', array(0), true);

//Check that a value equals another (==)
array('eq', array(1, 1), true);

//Check that a value does not equal another (!=)
array('notEq', array(1, 1), false);

//Check that a value is greater than another
array('greaterThan', array(1, 0), true);

//Check that a value is less than another
array('lessThan', array(1, 1), false);

//Check that a value is within a range
array('range', array(1, 1, 2), true);

//Check that a value is one of a list of values (alias of inArray)
array('oneOf', array(1, array(1, 2, 3)), true);




?>